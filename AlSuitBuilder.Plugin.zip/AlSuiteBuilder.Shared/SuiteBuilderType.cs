﻿namespace AlSuitBuilder.Shared
{
    public enum SuiteBuilderType
    {
        Unknown = 0,
        Dropoff = 10,
        DropoffRelay = 11,
        DeliveryBoi =100 

    }
}
