﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlSuitBuilder.Shared
{
    public enum SuiteBuilderState
    {
        Unknown = 0,
        Waiting = 100,
        Building = 1000

    }
}
